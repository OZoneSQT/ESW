# MSVC-FreeRTOS-Template-202012.00
A minimalistic FreeRTOS project only for Windows excl. demos etc.

Just clone this project to where you want to start a FreeRTOS project on windows

Example:

1. Go to the folder where you want your project stored
2. Open a command prompt and clone this repository: 
 
 **`git clone https://github.com/ihavn/MSVC-FreeRTOS-Template-202012.00 _[WANTED_NAME_OF_YOUR_PROJECT]_`**
 
3. Open the project in Visual Studio
4. Set the solution target to: **`x86`**
5. Rename the project to the project name you want
