#pragma once
#include <stdint.h>

void temperatureDriver_initDriver(uint8_t port);
float temperatureDriver_getVoltage();
